# Makes the room-related models available in the Django admin

from django.contrib import admin
from .models import Course, Thread, StudySession, SessionInvite

admin.site.register(Course)
admin.site.register(Thread)
admin.site.register(StudySession)
admin.site.register(SessionInvite)