# Makes forms for creating threads, posts, and study sessions

from django import forms
from .models import Thread, Post, StudySession
from accounts.models import User


class ThreadForm(forms.ModelForm):
    """Makes a form to create a new discussion thread"""

    class Meta:
        model = Thread
        fields = ['title', 'content']
        labels = {
            'title': 'Thread Title',
            'content': 'Your Post',
        }


class PostForm(forms.ModelForm):
    """Makes a form to reply to a thread"""

    class Meta:
        model = Post
        fields = ['content']
        labels = {
            'content': 'Your Reply',
        }


class BuddyChoiceField(forms.ModelMultipleChoiceField):
    """Makes a custom field that displays a buddy by their name instead of email"""

    def label_from_instance(self, obj: User) -> str:
        return f"{obj.first_name} {obj.last_name[0]}."


class SessionCreateForm(forms.ModelForm):
    """Makes a form to create a study session and select buddies to invite"""

    # Makes a field for selecting which buddies to invite
    buddies_to_invite = BuddyChoiceField(
        queryset=None,
        widget=forms.CheckboxSelectMultiple,
        required=True,
        label="Buddies to invite",
    )

    class Meta:
        model = StudySession
        fields = ['course', 'location', 'buddies_to_invite']
        labels = {
            'location': 'Location (Optional)',
        }

    def __init__(self, *args, **kwargs) -> None:
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        # Makes the queryset for buddies based on the provided user
        if user:
            self.fields['buddies_to_invite'].queryset = user.buddies.all()