# Makes database models for courses, threads, posts, study sessions, and session invites

from django.db import models
from django.conf import settings


class Course(models.Model):
    """Represents a course that students can join"""

    # Makes the course's name unique
    name = models.CharField(max_length=100, unique=True)
    # Makes a URL‑friendly version of the course name
    slug = models.SlugField(max_length=100, unique=True)
    # Makes an optional description of the course
    description = models.TextField(blank=True)

    def __str__(self) -> str:
        # Makes the course show its name when printed or displayed
        return self.name


class Thread(models.Model):
    """A discussion thread within a course"""

    # Makes a link to the course this thread belongs to
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='threads')
    # Makes the user who created the thread
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    # Makes the title of the thread
    title = models.CharField(max_length=255)
    # Makes the main content of the thread
    content = models.TextField()
    # Makes the timestamp when the thread was created
    created_at = models.DateTimeField(auto_now_add=True)
    # Makes the timestamp when the thread was last updated
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self) -> str:
        # Makes the thread show its title when printed or displayed
        return self.title


class Post(models.Model):
    """A reply posted within a thread"""

    # Makes a link to the thread this post belongs to
    thread = models.ForeignKey(Thread, on_delete=models.CASCADE, related_name='posts')
    # Makes the user who wrote the post
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    # Makes the text content of the post
    content = models.TextField()
    # Makes the timestamp when the post was created
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self) -> str:
        # Makes the post show its author and thread title when printed
        return f'Post by {self.author} on {self.thread.title}'


class StudySession(models.Model):
    """A study session for a course that users can join"""

    # Makes the user hosting the session
    host = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='hosted_sessions',
    )
    # Makes the course associated with the study session
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    # Makes the optional location where the session will be held
    location = models.CharField(max_length=255, blank=True)
    # Makes the timestamp when the session was created
    created_at = models.DateTimeField(auto_now_add=True)
    # Makes the set of participants in the session
    participants = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        related_name='joined_sessions',
        blank=True,
    )

    def __str__(self) -> str:
        # Makes a friendly description of the session with course name and host
        return f"Session for {self.course.name} hosted by {self.host.first_name}"


class SessionInvite(models.Model):
    """An invitation for a user to join a study session"""

    # Makes a link to the study session
    session = models.ForeignKey(
        StudySession,
        on_delete=models.CASCADE,
        related_name='invites',
    )
    # Makes the sender of the invite
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='sent_invites',
    )
    # Makes the receiver of the invite
    receiver = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='received_invites',
    )
    # Makes the timestamp when the invite was created
    created_at = models.DateTimeField(auto_now_add=True)
    # Makes the status of the invite: 'pending', 'accepted', or 'declined'
    status = models.CharField(max_length=10, default='pending')

    class Meta:
        unique_together = ('session', 'receiver')

    def __str__(self) -> str:
        # Makes a friendly description of who invited whom and for what session
        return f"Invite from {self.sender.first_name} to {self.receiver.first_name} for {self.session.course.name}"