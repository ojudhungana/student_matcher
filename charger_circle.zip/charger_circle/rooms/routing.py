# Makes WebSocket routes for notifications and course room messages

from django.urls import path
from . import consumers

# Makes the WebSocket routes for user notifications and for course room communication
websocket_urlpatterns = [
    path("ws/notifications/", consumers.NotificationConsumer.as_asgi()),
    path("ws/course_room/<slug:room_slug>/", consumers.RoomConsumer.as_asgi()),
]