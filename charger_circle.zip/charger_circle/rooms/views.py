# Makes views for courses, threads, study sessions and invite actions

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
from .models import Course, Thread, SessionInvite
from .forms import ThreadForm, PostForm, SessionCreateForm
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync


@login_required
def course_list_view(request):
    """Makes a page listing all courses except the hang‑out course"""
    courses = Course.objects.exclude(slug='hang-out')
    return render(request, 'rooms/course_list.html', {'courses': courses})


@login_required
def course_detail_view(request, slug):
    """Makes a page showing threads for a specific course and handles new thread creation"""
    course = get_object_or_404(Course, slug=slug)
    if request.method == 'POST':
        form = ThreadForm(request.POST)
        if form.is_valid():
            # Makes a new thread associated with the course and the current user
            thread = form.save(commit=False)
            thread.course = course
            thread.author = request.user
            thread.save()
            # Makes a broadcast so other users see the new thread without refreshing
            channel_layer = get_channel_layer()
            html = render_to_string(
                "rooms/partials/thread_item.html",
                {'thread': thread, 'course': course},
            )
            async_to_sync(channel_layer.group_send)(
                f'course_room_{course.slug}',
                {
                    'type': 'broadcast_message',
                    'html': html,
                    'message_type': 'new_thread',
                },
            )
    threads = course.threads.all()
    form = ThreadForm()
    context = {
        'course': course,
        'threads': threads,
        'form': form,
    }
    return render(request, 'rooms/course_detail.html', context)


@login_required
def thread_detail_view(request, slug, pk):
    """Makes a page showing posts for a specific thread and handles new post creation"""
    thread = get_object_or_404(Thread, pk=pk, course__slug=slug)
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            # Makes a new post associated with the thread and current user
            post = form.save(commit=False)
            post.thread = thread
            post.author = request.user
            post.save()
            # Makes a broadcast to other users so the new post appears instantly
            channel_layer = get_channel_layer()
            html = render_to_string("rooms/partials/post_item.html", {'post': post})
            async_to_sync(channel_layer.group_send)(
                f'course_room_{slug}',
                {
                    'type': 'broadcast_message',
                    'html': html,
                    'message_type': 'new_post',
                },
            )
    posts = thread.posts.all()
    form = PostForm()
    context = {
        'thread': thread,
        'posts': posts,
        'form': form,
    }
    return render(request, 'rooms/thread_detail.html', context)


@login_required
def create_session_view(request):
    """Makes a page to create a study session and invite buddies"""
    if request.method == 'POST':
        form = SessionCreateForm(request.POST, user=request.user)
        if form.is_valid():
            # Makes a new session hosted by the current user
            session = form.save(commit=False)
            session.host = request.user
            session.save()
            # Makes sure the host is included in the participant list
            session.participants.add(request.user)
            # Makes invites for each selected buddy
            invited_buddies = form.cleaned_data.get('buddies_to_invite')
            for buddy in invited_buddies:
                invite = SessionInvite.objects.create(
                    session=session,
                    sender=request.user,
                    receiver=buddy,
                )
                # Makes a real‑time notification to each invited buddy
                channel_layer = get_channel_layer()
                group_name = f'notifications_for_user_{buddy.pk}'
                message = {
                    'type': 'send_notification',
                    'message': {
                        'text': f'{request.user.first_name} invited you to a session for {session.course.name}!',
                        'invite_id': invite.pk,
                    },
                }
                async_to_sync(channel_layer.group_send)(group_name, message)
            return redirect('buddies')
    else:
        form = SessionCreateForm(user=request.user)
    return render(request, 'rooms/create_session.html', {'form': form})


@login_required
def accept_session_invite(request, invite_id):
    """Makes the action of accepting a study session invite"""
    invite = get_object_or_404(SessionInvite, id=invite_id, receiver=request.user)
    # Makes the user a participant in the session and removes the invite
    invite.session.participants.add(request.user)
    invite.delete()
    return render(request, 'rooms/partials/session_invite_accepted.html')


@login_required
def decline_session_invite(request, invite_id):
    """Makes the action of declining a study session invite"""
    invite = get_object_or_404(SessionInvite, id=invite_id, receiver=request.user)
    invite.delete()
    return render(request, 'rooms/partials/session_invite_declined.html')