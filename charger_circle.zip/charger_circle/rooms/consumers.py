# Makes WebSocket consumers for notifications and course room messages

import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.core.cache import cache
from django.utils import timezone
from asgiref.sync import async_to_sync

# Makes a constant for the global presence group name
PRESENCE_GROUP_NAME = 'global_presence'


class NotificationConsumer(AsyncWebsocketConsumer):
    """Handles notification and presence updates for authenticated users"""

    async def connect(self) -> None:
        # Makes us join notification and presence groups if the user is authenticated
        if self.scope["user"].is_authenticated:
            self.user = self.scope["user"]
            self.group_name = f'notifications_for_user_{self.user.pk}'

            # Makes us subscribe to the personal and global groups
            await self.channel_layer.group_add(self.group_name, self.channel_name)
            await self.channel_layer.group_add(PRESENCE_GROUP_NAME, self.channel_name)
            await self.accept()

            # Makes a call to the async version to mark the user as online
            await self.update_user_presence(is_online=True)
        else:
            await self.close()

    async def disconnect(self, close_code: int) -> None:
        # Makes us update presence and leave groups when the socket disconnects
        if hasattr(self, 'user'):
            await self.update_user_presence(is_online=False)
            if hasattr(self, 'group_name'):
                await self.channel_layer.group_discard(self.group_name, self.channel_name)
            await self.channel_layer.group_discard(PRESENCE_GROUP_NAME, self.channel_name)

    async def send_notification(self, event: dict) -> None:
        # Makes us send a notification payload to the browser
        await self.send(text_data=json.dumps({'type': 'notification', 'message': event['message']}))

    async def broadcast_presence(self, event: dict) -> None:
        # Makes us inform clients about presence updates
        await self.send(text_data=json.dumps({
            'type': 'presence_update',
            'user_pk': event['user_pk'],
            'status': event['status'],
        }))

    async def update_user_presence(self, is_online: bool) -> None:
        """Makes an async function to update the user's presence in cache and broadcast it"""
        await self.set_cache_last_seen()
        await self.channel_layer.group_send(
            PRESENCE_GROUP_NAME,
            {
                'type': 'broadcast_presence',
                'user_pk': self.user.pk,
                'status': 'online' if is_online else 'offline',
            },
        )

    @database_sync_to_async
    def set_cache_last_seen(self) -> None:
        # Makes sure database/cache operations run in an async context
        cache.set(f'last_seen_{self.user.pk}', timezone.now(), 300)


class RoomConsumer(AsyncWebsocketConsumer):
    """Handles messages within a course room"""

    async def connect(self) -> None:
        # Makes us join a course room group based on the slug and accept the connection
        self.room_slug = self.scope['url_route']['kwargs']['room_slug']
        self.room_group_name = f'course_room_{self.room_slug}'
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code: int) -> None:
        # Makes us leave the course room group when disconnected
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def broadcast_message(self, event: dict) -> None:
        # Makes us send a message broadcasted from the server to the browser
        await self.send(text_data=json.dumps(event))