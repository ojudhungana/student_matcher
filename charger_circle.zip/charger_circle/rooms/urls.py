# Makes URL routes for the rooms app

from django.urls import path
from .views import (
    course_list_view,
    course_detail_view,
    thread_detail_view,
    create_session_view,
    accept_session_invite,
    decline_session_invite,
)

urlpatterns = [
    path('', course_list_view, name='course_list'),  # Makes the course list page
    path('create-session/', create_session_view, name='create_session'),  # Makes the page to create a study session
    path('session-invite/accept/<int:invite_id>/', accept_session_invite, name='accept_session_invite'),  # Makes the URL to accept invites
    path('session-invite/decline/<int:invite_id>/', decline_session_invite, name='decline_session_invite'),  # Makes the URL to decline invites
    path('<slug:slug>/', course_detail_view, name='course_detail'),  # Makes the detail page for a course
    path('<slug:slug>/<int:pk>/', thread_detail_view, name='thread_detail'),  # Makes the detail page for a thread
]