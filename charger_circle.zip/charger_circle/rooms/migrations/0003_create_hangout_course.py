# rooms/migrations/0002_create_hangout_course.py

from django.db import migrations

def create_hangout_course(apps, schema_editor):
    """
    Creates the special 'Hang Out' course that will be auto-assigned to new users.
    """
    Course = apps.get_model('rooms', 'Course')
    Course.objects.get_or_create(
        name='Hang Out',
        slug='hang-out',
        defaults={'description': 'A place for casual connections and making friends.'}
    )

class Migration(migrations.Migration):

    dependencies = [
        ('rooms', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(create_hangout_course),
    ]