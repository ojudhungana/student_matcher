# Makes WebSocket consumers for chat messages between users
import json
from channels.generic.websocket import AsyncWebsocketConsumer
from django.contrib.auth import get_user_model
from asgiref.sync import sync_to_async # Makes conversion of sync functions to async
from .models import Message

User = get_user_model()

class ChatConsumer(AsyncWebsocketConsumer):
    # Makes a WebSocket consumer that handles private chat between two users
    async def connect(self):
        # Makes us join a room based on the two users' IDs and accept the WebSocket connection
        my_id = int(self.scope['user'].id)
        other_user_id = int(self.scope['url_route']['kwargs']['buddy_id'])
        
        if my_id > other_user_id:
            self.room_name = f'{my_id}-{other_user_id}'
        else:
            self.room_name = f'{other_user_id}-{my_id}'
        
        self.room_group_name = f'chat_{self.room_name}'

        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Makes us leave the chat group when the socket disconnects
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        # Makes us handle incoming messages or typing notifications
        data = json.loads(text_data)
        message_type = data.get('type', 'chat_message')

        if message_type == 'typing':
            await self.channel_layer.group_send(
                self.room_group_name,
                {'type': 'typing_indicator', 'sender_id': data['sender_id']}
            )
        else:
            # Makes us treat it as a chat message
            message_content = data['message']
            sender_id = data['sender_id']
            try:
                sender = await self.get_user_instance(sender_id)
                receiver = await self.get_user_instance(data['receiver_id'])
                await self.create_message(sender, receiver, message_content)

                await self.channel_layer.group_send(
                    self.room_group_name,
                    {'type': 'chat_message', 'message': message_content, 'sender_id': sender_id}
                )
            except Exception as e:
                # Makes sure we see errors during development
                print(f"ERROR in ChatConsumer: {e}")

    async def chat_message(self, event):
        # Makes us send a chat message to the browser
        await self.send(text_data=json.dumps({
            'type': 'chat_message', 
            'message': event['message'], 
            'sender_id': event['sender_id']
        }))

    async def typing_indicator(self, event):
        # Makes us send a typing indicator to the browser
        await self.send(text_data=json.dumps({
            'type': 'typing', 
            'sender_id': event['sender_id']
        }))
    
    @sync_to_async
    def create_message(self, sender, receiver, content):
        # Makes a new Message record in the database
        return Message.objects.create(sender=sender, receiver=receiver, content=content)

    @sync_to_async
    def get_user_instance(self, user_id):
        # Makes a database query to find a user by their primary key
        return User.objects.get(pk=user_id)