# Makes a database model for user-to-user messages

from django.db import models
from django.conf import settings


class Message(models.Model):
    """A record of a single message sent from one user to another"""

    # Makes a reference to the user sending the message
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='sent_messages',
    )
    # Makes a reference to the user receiving the message
    receiver = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='received_messages',
    )
    # Makes the text content of the message
    content = models.TextField()
    # Makes the timestamp when the message is created automatically
    timestamp = models.DateTimeField(auto_now_add=True)
    # Makes a flag to indicate if the message has been read
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ['timestamp']

    def __str__(self) -> str:
        """Makes a human‑readable description showing who sent the message and when"""
        return f"From {self.sender} to {self.receiver} at {self.timestamp}"