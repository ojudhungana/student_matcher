# Makes WebSocket routes for chat in the messaging app

from django.urls import re_path
from . import consumers

# Makes the WebSocket route for chatting with a specific buddy
websocket_urlpatterns = [
    re_path(r'ws/chat/(?P<buddy_id>\d+)/$', consumers.ChatConsumer.as_asgi()),
]