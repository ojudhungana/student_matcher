# Makes the Message model manageable in the Django admin

from django.contrib import admin
from .models import Message

admin.site.register(Message)