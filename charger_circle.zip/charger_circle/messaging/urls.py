# Makes URL routes for the messaging app

from django.urls import path
from .views import inbox_view


urlpatterns = [
    path('', inbox_view, name='inbox'),  # Makes the inbox page
    path('<int:buddy_id>/', inbox_view, name='conversation'),  # Makes a conversation page with a specific buddy
]