# Makes views for the messaging features like the inbox
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from accounts.models import User
from .models import Message
from .forms import MessageForm
from core.utils import get_online_user_ids

@login_required
def inbox_view(request, buddy_id=None):
    # Makes the messaging inbox; shows our buddies and messages with the selected buddy
    my_buddies = request.user.buddies.exclude(pk=request.user.pk)
    selected_buddy = None
    messages = []
    form = MessageForm()
    if buddy_id:
        selected_buddy = get_object_or_404(User, pk=buddy_id)
        messages = Message.objects.filter(
            (Q(sender=request.user) & Q(receiver=selected_buddy)) |
            (Q(sender=selected_buddy) & Q(receiver=request.user))
        ).order_by('timestamp')
    online_user_ids = get_online_user_ids()
    context = {
        'my_buddies': my_buddies,
        'selected_buddy': selected_buddy,
        'messages': messages,
        'form': form,
        'online_user_ids': online_user_ids,
    }
    return render(request, 'messaging/inbox.html', context)