# Makes the ASGI application hooking up HTTP and WebSocket routes for Django and Channels

import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from rooms import routing as rooms_routing # Makes us import the room websocket routes
from messaging import routing as messaging_routing # Makes us import the messaging websocket routes

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

django_asgi_app = get_asgi_application()

application = ProtocolTypeRouter({
    "http": django_asgi_app,
    "websocket": AuthMiddlewareStack(
        URLRouter(
            rooms_routing.websocket_urlpatterns + 
            messaging_routing.websocket_urlpatterns
        )
    ),
})