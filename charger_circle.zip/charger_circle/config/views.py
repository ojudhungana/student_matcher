# Makes simple views for the project

from django.shortcuts import render, redirect

def home_view(request):
    # Makes the landing page; if a user is logged in we send them to the dashboard
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'home.html')