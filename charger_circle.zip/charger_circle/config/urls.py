# Makes the URL configuration for the entire Django project

from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse
from .views import home_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('healthz/', lambda r: HttpResponse("ok", content_type="text/plain")),
    path('', home_view, name='home'),
    path('accounts/', include('accounts.urls')),
    path('rooms/', include('rooms.urls')),
    path('messages/', include('messaging.urls')),
]