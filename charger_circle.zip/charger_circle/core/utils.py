# Makes utility functions used across the project
from django.core.cache import cache
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth import get_user_model

User = get_user_model()

def get_online_user_ids():
    # Makes a set of user IDs for users who have been active in the last two minutes
    online_ids = set()
    # This simple approach loops through all users; for larger sites, we would query the cache more directly
    all_users = User.objects.all()
    for user in all_users:
        last_seen = cache.get(f'last_seen_{user.pk}')
        if last_seen and (timezone.now() - last_seen) < timedelta(minutes=2):
            online_ids.add(user.pk)
    return online_ids