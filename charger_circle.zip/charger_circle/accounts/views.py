# Makes views for user accounts like dashboard, signup, discover, buddy requests and managing buddies

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from .forms import CustomUserCreationForm
from .services import find_matches
from .models import BuddyRequest
from rooms.models import Course, SessionInvite
from core.utils import get_online_user_ids

User = get_user_model()


@login_required
def dashboard_view(request):
    """Makes the dashboard page for the current user"""
    return render(request, 'dashboard.html')


def signup_view(request):
    """Makes the signup page where new users can register"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Makes the new user automatically join the hang‑out course if it exists
            try:
                hangout_course = Course.objects.get(slug='hang-out')
                user.courses.add(hangout_course)
            except Course.DoesNotExist:
                pass
            login(request, user)
            return redirect('dashboard')
    else:
        form = CustomUserCreationForm()
    return render(request, 'accounts/signup.html', {'form': form})


def logout_view(request):
    """Makes the user log out and then redirects home"""
    logout(request)
    return redirect('home')


@login_required
def discover_view(request):
    """Makes a page showing buddy matches for the current user"""
    matches = find_matches(request.user)
    return render(request, 'accounts/discover.html', {'matches': matches})


@login_required
def send_buddy_request(request, pk):
    """Makes an endpoint to send a buddy request to another user"""
    to_user = get_object_or_404(User, pk=pk)
    if to_user != request.user:
        BuddyRequest.objects.get_or_create(from_user=request.user, to_user=to_user)
    return render(request, 'accounts/partials/buddy_request_sent.html')


@login_required
def buddies_view(request):
    """Makes the page listing incoming buddy requests, current buddies, and session invites"""
    incoming_buddy_requests = BuddyRequest.objects.filter(to_user=request.user)
    buddy_list = request.user.buddies.all()
    incoming_session_invites = SessionInvite.objects.filter(
        receiver=request.user,
        status='pending',
    )
    online_user_ids = get_online_user_ids()
    context = {
        'incoming_buddy_requests': incoming_buddy_requests,
        'buddy_list': buddy_list,
        'incoming_session_invites': incoming_session_invites,
        'online_user_ids': online_user_ids,
    }
    return render(request, 'accounts/buddies.html', context)


@login_required
def accept_buddy_request(request, request_id):
    """Makes the action of accepting a buddy request and notifying the requester"""
    buddy_request = get_object_or_404(
        BuddyRequest,
        id=request_id,
        to_user=request.user,
    )
    # Makes and sends a real‑time notification to the requester
    channel_layer = get_channel_layer()
    group_name = f'notifications_for_user_{buddy_request.from_user.pk}'
    message = {
        'type': 'send_notification',
        'message': {
            'text': f'{request.user.first_name} accepted your buddy request!',
        },
    }
    async_to_sync(channel_layer.group_send)(group_name, message)
    # Makes both users buddies of each other
    request.user.buddies.add(buddy_request.from_user)
    buddy_request.from_user.buddies.add(request.user)
    buddy_request.delete()
    return buddies_view(request)


@login_required
def decline_buddy_request(request, request_id):
    """Makes the action of declining a buddy request"""
    buddy_request = get_object_or_404(
        BuddyRequest,
        id=request_id,
        to_user=request.user,
    )
    buddy_request.delete()
    return buddies_view(request)


@login_required
def remove_buddy(request, pk):
    """Makes the action of removing a buddy from your buddy list"""
    buddy_to_remove = get_object_or_404(User, pk=pk)
    request.user.buddies.remove(buddy_to_remove)
    buddy_to_remove.buddies.remove(request.user)
    return HttpResponse('')