# Makes our custom user and buddy request models
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.conf import settings
from .managers import CustomUserManager
from rooms.models import Course

class User(AbstractUser):
    # Makes a custom user who uses email instead of username and stores buddies and courses
    username = None
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=150, blank=False)
    last_name = models.CharField(max_length=150, blank=False)
    age = models.PositiveIntegerField(null=True, blank=True)
    buddies = models.ManyToManyField('self', blank=True, symmetrical=False)
    courses = models.ManyToManyField(Course, blank=True, related_name='students')

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    objects = CustomUserManager()

    def __str__(self):
        return self.email

class BuddyRequest(models.Model):
    # Makes a record of one user asking another to be buddies
    from_user = models.ForeignKey(User, related_name='from_user', on_delete=models.CASCADE)
    to_user = models.ForeignKey(User, related_name='to_user', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        # Makes sure a user can only send one request to another user at a time
        unique_together = ('from_user', 'to_user')

    def __str__(self):
        return f"From {self.from_user.email} to {self.to_user.email}"