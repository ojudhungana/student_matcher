# Makes URL routes for account related pages like signup, login, and buddies
from django.urls import path
from django.contrib.auth import views as auth_views
from .views import (
    signup_view, logout_view, discover_view, send_buddy_request, 
    buddies_view, accept_buddy_request, decline_buddy_request, remove_buddy,
    dashboard_view
)

urlpatterns = [
    path('signup/', signup_view, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', logout_view, name='logout'),
    path('discover/', discover_view, name='discover'),
    path('buddies/', buddies_view, name='buddies'),
    path('dashboard/', dashboard_view, name='dashboard'), # Makes the dashboard path for logged-in users
    path('buddy-request/send/<int:pk>/', send_buddy_request, name='send_buddy_request'),
    path('buddy-request/accept/<int:request_id>/', accept_buddy_request, name='accept_buddy_request'),
    path('buddy-request/decline/<int:request_id>/', decline_buddy_request, name='decline_buddy_request'),
    path('buddy/remove/<int:pk>/', remove_buddy, name='remove_buddy'),
]