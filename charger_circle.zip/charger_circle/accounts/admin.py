# Makes admin configuration for our custom user and buddy requests
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, BuddyRequest

class CustomUserAdmin(UserAdmin):
    model = User
    list_display = ('email', 'first_name', 'last_name', 'age', 'is_staff')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'groups')
    search_fields = ('email', 'first_name', 'last_name')
    ordering = ('email',)

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'age')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser',)}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
        ('Buddies & Courses', {'fields': ('buddies', 'courses')}),
    )
    filter_horizontal = ('buddies', 'courses', 'groups', 'user_permissions')

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'first_name', 'last_name', 'age', 'password', 'password2'),
        }),
    )

admin.site.register(User, CustomUserAdmin)
admin.site.register(BuddyRequest) # Makes the BuddyRequest model manageable in the admin