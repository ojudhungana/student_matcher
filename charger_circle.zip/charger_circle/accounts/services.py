# Makes helper services for the accounts app
from .models import User

def find_matches(user):
    # Makes a list of potential buddy matches based on shared courses and similar age
    user_courses = user.courses.all()
    user_buddies = user.buddies.all()

    potential_matches = User.objects.exclude(pk=user.pk).exclude(pk__in=[buddy.pk for buddy in user_buddies])

    matches_with_scores = []
    for match in potential_matches:
        score = 0
        
        # Makes us calculate how many courses we share
        match_courses = match.courses.all()
        shared_courses = set(user_courses) & set(match_courses)
        
        # Makes sure we do not show the 'hang-out' course in the list of shared courses
        shared_academic_courses = [course for course in shared_courses if course.slug != 'hang-out']

        if shared_courses:
            # Makes sure the score counts all shared courses, including 'hang‑out'
            score += 60 * len(shared_courses)

        if user.age and match.age:
            if abs(user.age - match.age) <= 2:
                score += 10

        if score > 0:
            matches_with_scores.append({
                'user': match,
                'score': score,
                'shared_courses': shared_academic_courses, # Makes us return the filtered list of courses
            })

    sorted_matches = sorted(matches_with_scores, key=lambda k: k['score'], reverse=True)
    return sorted_matches