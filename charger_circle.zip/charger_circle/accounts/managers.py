# Makes a custom manager that uses email as the username for authentication
from django.contrib.auth.base_user import BaseUserManager

class CustomUserManager(BaseUserManager):
    # Makes a manager where the user's email is used for login instead of a username
    def create_user(self, email, password, **extra_fields):
        # Makes a regular user with the provided email and password
        if not email:
            raise ValueError('The Email must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        # Makes a superuser with administrative privileges
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')
        return self.create_user(email, password, **extra_fields)