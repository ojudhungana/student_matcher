# Makes a registration form for our custom user using Django's built-in UserCreationForm
from django.contrib.auth.forms import UserCreationForm
from .models import User

class CustomUserCreationForm(UserCreationForm):
    # Makes a user creation form that collects email, first name, last name, and age
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('email', 'first_name', 'last_name', 'age')