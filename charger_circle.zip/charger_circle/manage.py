#!/usr/bin/env python
# Makes this script handle Django's command-line tasks for the project
import os
import sys


def main():
    # Makes sure we set the default settings module and call Django's command runner
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    # Makes Python hand off the command-line arguments to Django
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    # Makes this script runnable as a program
    main()